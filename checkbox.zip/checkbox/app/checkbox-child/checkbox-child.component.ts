import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { runInThisContext } from 'vm';

@Component({
  selector: 'app-checkbox-child',
  templateUrl: './checkbox-child.component.html',
  styleUrls: ['./checkbox-child.component.css']
})
export class CheckboxChildComponent implements OnInit {

  constructor() { }
  @Input() checked: boolean;
  @Input() name: boolean;
  @Input() value: any;
  @Input() heading: boolean;
  @Output() onChangeEvent = new EventEmitter();
  @Output() changeDetected = new EventEmitter();
  ngOnInit() {
  }

  onChange(event) {
    console.log(event)
    const model = {
      name:this.name,
      value:this.value
    }
    console.log(model);
      this.changeDetected.emit();// checkbox is changed
    if(this.checked) {
    this.onChangeEvent.emit(model);
    } else {
      const model = { }
      this.onChangeEvent.emit(model);
    }
  }

}
