import { compileComponentFromRender2 } from '@angular/compiler/src/render3/view/compiler';
import { AfterContentInit, AfterViewInit, Component, ContentChildren, forwardRef, OnInit, QueryList } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import {CheckboxChildComponent} from '../checkbox-child/checkbox-child.component'
@Component({
  selector: 'app-checkbox-parent',
  template: '<ng-content></ng-content>',
  styleUrls: ['./checkbox-parent.component.css'],
  providers:[
    {
      provide:NG_VALUE_ACCESSOR,
      useExisting:forwardRef(() => CheckboxParentComponent),
      multi:true
    }
  ]
})
export class CheckboxParentComponent implements OnInit,AfterViewInit,AfterContentInit {
  propagationModelChange = (_:any) => {};
  OnTouchedEvent = () => {};

  constructor() { }
  public model : any;
  @ContentChildren(CheckboxChildComponent) checkboxChild:QueryList<CheckboxChildComponent>
  ngOnInit() {
  }

  writeValue(value:any) {
console.log(value);
if(value) {
  this.model = value;
  this.preDefinedSelection(this.model);
}
  }
  registerOnChange(fn:any) {
    this.propagationModelChange = fn;
  }

  registerOnTouched(fn:any) {
    this.OnTouchedEvent = fn;
  }

  preDefinedSelection(model) {
    if(this.checkboxChild) {
      this.model = new Array();
      this.checkboxChild.toArray().forEach((Comp:CheckboxChildComponent,index) =>{
        if(typeof model === 'string') {
          console.log(model)
          if(model === Comp.value){
             this.updateModel(Comp,index)
          }
        }
      })
    }
  }


  updateModel(Comp:CheckboxChildComponent,index) {
    Comp.checked = true;
    this.model.push({name:Comp.name || '' , value:Comp.value,index})
  }
  ngAfterViewInit(): void {
    
  }

  ngAfterContentInit(): void {

    this.checkboxChild.toArray().forEach((Comp:CheckboxChildComponent,index) => {

      Comp.changeDetected.subscribe(() =>{
        if(Comp.checked) {
          this.model.push({name:Comp.name || '' , value:Comp.value,index})
        } else {
          for(let i=0;i< this.model.length;i++) {
            if(this.model[i].index === index) {
              this.model.splice(i,1)
            }
          }
        }
      })
    })
    
  }
}
