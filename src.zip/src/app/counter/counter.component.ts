import { Component, OnInit, Output,EventEmitter, Input, HostListener } from '@angular/core';

@Component({
  selector: '[app-counter]',
  template: '',
  host:{'[attr.maxlength]':'max'}
})
export class CounterComponent implements OnInit {
 @Input() max: number;
 @Output() countUpdated = new EventEmitter();
  countDown: number;
  constructor() { }

  ngOnInit() {
    this.countUpdated.emit(this.max)
  }

  onChange(data) {
    const text = data? data.length : 0;
    this.countDown = this.max - text;
    this.countUpdated.emit(this.countDown)
  }

  @HostListener('input',['$event','$event.target.value'])
  onInputChange(event,value){
    this.updateChange(value)
  }
  updateChange(value) {
    this.onChange(value)
  }


}
