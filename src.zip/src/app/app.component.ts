import { Component,ElementRef,OnInit,ViewChild } from '@angular/core';
import { FormBuilder,FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angular-checkbox';
  public sample = 'male';
  cbList = [
    {'name':'gender','value':'male','heading':'male'},
    {'name':'gender','value':'female','heading':'female'},
    {'name':'gender','value':'other','heading':'other'}
  ]
  onChange(event) {
    console.log(event)
  }
  @ViewChild('data') childElement: any;
  public checkboxForm;

  ngOnInit(): void {

  }
  deselect() {
    this.childElement.deSelectAllCheckbox()
  }

}
