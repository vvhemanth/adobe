import { AfterContentInit, AfterViewInit, Component, ContentChildren, forwardRef, Input, OnInit, QueryList } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CheckboxChildComponent } from '../checkbox-child/checkbox-child.component';

@Component({
  selector: 'app-checkbox-parent',
  template: '<ng-content></ng-content>',
  styleUrls: ['./checkbox-parent.component.css'],
  providers:[{
    provide:NG_VALUE_ACCESSOR,
    useExisting:forwardRef(() => CheckboxParentComponent),
    multi:true
  },
  {
    provide:NG_VALIDATORS,
    useExisting:forwardRef(() => CheckboxParentComponent),
    multi:true
  }
]
})
export class CheckboxParentComponent implements OnInit,AfterContentInit,AfterViewInit {
  model: any;
  @Input() isAllChecked:boolean;
  @Input() isAllDisabled:boolean;
  @ContentChildren(CheckboxChildComponent) checkboxChild:QueryList<CheckboxChildComponent>
  required: any;
  constructor() { }
 private propagationModelChange = (_:any) =>{}
 private OnTouchedEvent = () =>{}
  ngOnInit() {
  }

  ngAfterViewInit(): void {
      
  }

  ngAfterContentInit(): void {
    this.checkboxChild.toArray().forEach((comp:CheckboxChildComponent,index) => {
      comp.chnagedetect.subscribe(() =>{
        if(comp.checked) {
          this.model.push({name:comp.name || ' ',value:comp.value,index})
        } else {
          for(let i=0;i< this.model.length;i++) {
            if(this.model[i].index === index) {
              this.model.splice(i,1)
            }
          }
        }
        this.propagationModelChange(this.model)
      })
      comp.emitBlur.subscribe(()=>{
        this.OnTouchedEvent();
      })

      if(this.isAllChecked){
        this.selectAllCheckbox();
      }
      if(this.isAllDisabled){
        this.disableAllCheckbox();
      }
    })
  }
  selectAllCheckbox() {
    this.model = new Array();
    this.checkboxChild.toArray().forEach((comp:CheckboxChildComponent,index) => {
      comp.checked = true;
      this.model.push({name:comp.name || ' ',value:comp.value,index})
    })
  }
  deSelectAllCheckbox() {
    this.checkboxChild.toArray().forEach((comp:CheckboxChildComponent,index) => {
      comp.checked = false;
   this.model = new Array();
    })
  }

  disableAllCheckbox() {
    this.checkboxChild.toArray().forEach((comp:CheckboxChildComponent,index) => {
      comp.disabled = !comp.disabled;
 
    })
  }
  writeValue(value:any) {
    if(value || value === 0) {
      this.model = value;
      this.preDefinedSelection(this.model)
    }
  }

  registerOnChange(fn:any) {
    this.propagationModelChange = fn;

  }

  registerOnTouched(fn:any):void {
    this.OnTouchedEvent = fn;
  }
  validate(control:AbstractControl) {
    if(this.required) {
      if(control.value != -1) {
        return null;
      }
      return {checkbox:{valid:false}}
    }
  }

  preDefinedSelection(model) {
    const length = model.length;
    if(this.checkboxChild) {
      this.model = new Array<any>();
      this.checkboxChild.toArray().forEach((comp:CheckboxChildComponent,index) => {
        if(typeof model === 'string') {
          if(model === comp.value) {
            this.updateModel(comp,index)
          } 
        }
      });
    }
  }

  updateModel(comp:CheckboxChildComponent,index) {
    comp.checked = true;
    this.model.push({name:comp.name || ' ',value:comp.value,index})
  }
}
