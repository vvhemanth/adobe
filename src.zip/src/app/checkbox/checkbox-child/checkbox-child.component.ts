import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-checkbox-child',
  templateUrl: './checkbox-child.component.html',
  styleUrls: ['./checkbox-child.component.css']
})
export class CheckboxChildComponent implements OnInit {

  @Input() checked:boolean;
  @Input() disabled:boolean;
  @Input() name: any;
  @Input() heading: any;
  @Input() value: any;
  @Output() onChangeEvent = new EventEmitter();
  @Output() chnagedetect = new EventEmitter();
  @Output() emitBlur = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  onChange(e?) {
 const model = {
   name:this.name,
   value:this.value
 };
 console.log(model)
 this.onChangeEvent.emit(model);
 this.chnagedetect.emit(model)

  }
  emitOnBlur() {
    this.emitBlur.emit();
  }
}
